/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["9a1e"],{z3YN:function(e,t,a){"use strict";Object.defineProperty(t,"__esModule",{value:!0});window.am4geodata_vaticanHigh={type:"FeatureCollection",features:[{type:"Feature",geometry:{type:"Polygon",coordinates:[[[12.4556,41.9076],[12.4558,41.9064],[12.4578,41.9059],[12.4577,41.905],[12.4577,41.9044],[12.4576,41.9036],[12.4577,41.9033],[12.4579,41.9032],[12.4582,41.9029],[12.4583,41.9028],[12.4584,41.9025],[12.4585,41.9022],[12.4584,41.9018],[12.4582,41.9016],[12.4579,41.9013],[12.4575,41.9012],[12.4572,41.9012],[12.4569,41.9012],[12.4567,41.9013],[12.4564,41.9015],[12.4561,41.9014],[12.455,41.9011],[12.4544,41.901],[12.4541,41.9009],[12.4541,41.9008],[12.4541,41.9005],[12.4542,41.9004],[12.4542,41.9003],[12.4541,41.9001],[12.4539,41.9002],[12.4529,41.9005],[12.4529,41.9003],[12.4528,41.9003],[12.4512,41.9005],[12.4507,41.9006],[12.4506,41.9007],[12.4503,41.9008],[12.4498,41.9009],[12.4496,41.9009],[12.4491,41.901],[12.4488,41.901],[12.4488,41.9008],[12.4483,41.9007],[12.4479,41.9007],[12.4477,41.9009],[12.4479,41.901],[12.4476,41.9013],[12.447,41.9016],[12.4466,41.9018],[12.4465,41.9017],[12.446,41.9019],[12.4456,41.902],[12.4468,41.9025],[12.4473,41.9028],[12.4474,41.903],[12.4476,41.9034],[12.4478,41.9035],[12.448,41.9036],[12.4482,41.9038],[12.4484,41.904],[12.4486,41.9041],[12.4486,41.9043],[12.4488,41.9051],[12.449,41.9052],[12.4495,41.9054],[12.4498,41.9056],[12.4501,41.9059],[12.4504,41.9066],[12.4513,41.9067],[12.4519,41.9066],[12.452,41.9067],[12.4527,41.9069],[12.453,41.9069],[12.4532,41.9067],[12.4538,41.9069],[12.4538,41.9071],[12.4542,41.9072],[12.4556,41.9076]]]},properties:{name:"Vatican City",id:"VA",NAME_VARIA:"Holy See",CNTRY:"Vatican City",TYPE:"City State"},id:"VA"}]}}},["z3YN"]);
//# sourceMappingURL=vaticanHigh.js.map